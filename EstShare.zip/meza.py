from meza import io
records = io.read('RSEPS_Back.mdb') # only file path, no file objects
print(next(records))